# Redirection

This is the GitHub repository for Joe Wack Fan Club #2

In this repo will we code our website application

PROJECT NOTES

Languages

Backend:
- Backend should be coded in Java and potentially some python
- Frontend should be coded in JS and HTML using whatever plugins or libraries are needed to make the site polished
